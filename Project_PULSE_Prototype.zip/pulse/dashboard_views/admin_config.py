import streamlit as st

import db
import program_ctx
import ui_helpers

user = st.session_state["user"]
if user["role"] != "IT_Admin":
    st.error("Admin Config is restricted to the IT/Admin role.")
    st.stop()

active_program = program_ctx.get_active_program()
ui_helpers.page_shell("Admin Config", user, active_program["ProgramName"], active_program["Term"])
program_id = active_program["ProgramID"]

# =============================================================================
# US-02: choose which Program instance the whole dashboard is filtered to.
# =============================================================================
st.subheader("Active Program Instance (US-02)")
programs = program_ctx.list_programs()
labels = {p["ProgramName"]: p for p in programs}
current_label = active_program["ProgramName"]

col1, col2 = st.columns([3, 1])
with col1:
    chosen = st.selectbox("Active program instance", list(labels.keys()),
                           index=list(labels.keys()).index(current_label))
with col2:
    term = st.text_input("Term", value=active_program["Term"])

if st.button("Set as Active Program"):
    program_ctx.set_active_program(labels[chosen]["ProgramID"], term)
    st.success(f"Active program set to {chosen} ({term}).")
    st.rerun()

with st.expander("+ Add a new Program"):
    with st.form("new_program"):
        code = st.text_input("Program Code (e.g. MSCS)")
        name = st.text_input("Program Name (e.g. MS Computer Science)")
        if st.form_submit_button("Create Program"):
            if code and name:
                new_id = program_ctx.create_program(code.upper(), name)
                # Seed default field mapping + threshold so the new program
                # instance is usable immediately without code changes.
                with db.get_cursor(commit=True) as cur:
                    for label_, col_ in [
                        ("Student ID", "dbo.Students.StudentNumber"),
                        ("Student Name", "dbo.Students.FirstName, dbo.Students.LastName"),
                        ("Cohort", "dbo.Students.Cohort"),
                        ("Coursework Status", "dbo.Student_Lifecycle.CourseworkStatus"),
                        ("Comprehensive Exam Status", "dbo.Student_Lifecycle.CompExamStatus"),
                        ("Capstone Status", "dbo.Student_Lifecycle.CapstoneDefended/Completed"),
                        ("Assigned Advisor", "dbo.Advisor.AdvisorName"),
                    ]:
                        cur.execute(
                            "INSERT INTO Field_Mapping (ProgramID, UILabel, ColumnPath, IsMapped) VALUES (?,?,?,1)",
                            (new_id, label_, col_),
                        )
                    cur.execute("INSERT INTO Risk_Thresholds (ProgramID, AtRiskDays) VALUES (?,180)", (new_id,))
                st.success(f"Program '{name}' created. No source data copied — add students separately.")
                st.rerun()
            else:
                st.warning("Program Code and Name are both required.")

st.divider()

# =============================================================================
# US-10: field mapping screen
# =============================================================================
st.subheader("Field Mapping (US-10)")
st.caption("Maps dashboard fields to the underlying schema — no code changes required to repoint for a new program.")

with db.get_cursor() as cur:
    cur.execute("SELECT * FROM Field_Mapping WHERE ProgramID=? ORDER BY MappingID", (program_id,))
    mappings = [dict(r) for r in cur.fetchall()]

for m in mappings:
    c1, c2, c3, c4 = st.columns([2, 3, 1, 1])
    c1.write(f"**{m['UILabel']}**")
    new_col = c2.text_input("Source column", value=m["ColumnPath"], key=f"map_{m['MappingID']}", label_visibility="collapsed")
    is_flagged = not new_col.strip()
    c3.markdown("🚩 Missing" if is_flagged else "✅ Mapped")
    if c4.button("Save", key=f"savemap_{m['MappingID']}"):
        with db.get_cursor(commit=True) as cur:
            cur.execute("UPDATE Field_Mapping SET ColumnPath=?, IsMapped=? WHERE MappingID=?",
                        (new_col.strip(), int(bool(new_col.strip())), m["MappingID"]))
        st.success(f"Updated mapping for {m['UILabel']}.")
        st.rerun()

missing = [m for m in mappings if not m["ColumnPath"].strip()]
if missing:
    st.warning(f"{len(missing)} field mapping(s) are missing and will be flagged before this dashboard goes live.")

st.divider()

# =============================================================================
# US-11: connection status (managed credentials, visible error not a silent
# blank dashboard).
# =============================================================================
st.subheader("Database Connection (US-11)")
try:
    with db.get_cursor() as cur:
        cur.execute("SELECT 1")
    st.success(f"Connected · engine = `{db.DB_ENGINE}` · read via a scoped connection, not a personal login.")
except db.DBConnectionError as e:
    st.error(f"Connection failed: {e}")
st.caption(
    "In production this points at the real SQL Server/MySQL instance via a read-only service "
    "account, with credentials in `.env` (never hardcoded — see db.py's commented reference "
    "implementation)."
)

st.divider()

# =============================================================================
# US-13: permission levels — only IT_Admin can reach this page at all, which
# already satisfies "only IT/Admin can change permission levels."
# =============================================================================
st.subheader("Permission Levels (US-13)")
with db.get_cursor() as cur:
    cur.execute("SELECT * FROM Role_Permissions")
    perms = [dict(r) for r in cur.fetchall()]

for p in perms:
    c1, c2 = st.columns([2, 1])
    c1.write(f"**{p['Role']}**")
    new_val = c2.toggle("Can edit student data", value=bool(p["CanEditStudentData"]), key=f"perm_{p['Role']}")
    if new_val != bool(p["CanEditStudentData"]):
        with db.get_cursor(commit=True) as cur:
            cur.execute(
                "UPDATE Role_Permissions SET CanEditStudentData=?, UpdatedBy=?, UpdatedAt=? WHERE Role=?",
                (int(new_val), user["UserID"], db.now_iso(), p["Role"]),
            )
        st.rerun()

st.divider()

# =============================================================================
# US-14: RYG thresholds, configurable not hardcoded.
# =============================================================================
st.subheader("At-Risk Threshold (US-14)")
with db.get_cursor() as cur:
    cur.execute("SELECT AtRiskDays FROM Risk_Thresholds WHERE ProgramID=?", (program_id,))
    row = cur.fetchone()
current_days = row["AtRiskDays"] if row else 180
new_days = st.number_input("Days in a single stage before flagged 'At Risk'", min_value=30, max_value=730,
                            value=current_days, step=10)
if st.button("Save threshold"):
    with db.get_cursor(commit=True) as cur:
        cur.execute(
            "INSERT INTO Risk_Thresholds (ProgramID, AtRiskDays) VALUES (?,?) "
            "ON CONFLICT(ProgramID) DO UPDATE SET AtRiskDays=excluded.AtRiskDays",
            (program_id, new_days),
        )
    st.success("Threshold updated.")
    st.rerun()

st.divider()

# =============================================================================
# US-16: sync/error log viewer + repeated-failure banner.
# =============================================================================
st.subheader("System / Sync Logs (US-16)")
with db.get_cursor() as cur:
    cur.execute("SELECT * FROM Sync_Logs ORDER BY LogID DESC LIMIT 20")
    logs = [dict(r) for r in cur.fetchall()]

recent_statuses = [l["Status"] for l in logs[:3]]
if recent_statuses.count("FAILED") >= 2:
    st.error("⚠️ Repeated sync failures detected — investigate before trusting the dashboard's numbers.")

if logs:
    rows = [{"When": l["Timestamp"], "Status": l["Status"], "Retry #": l["RetryCount"],
              "Error": l["ErrorMessage"] or "—"} for l in logs]
    st.dataframe(rows, use_container_width=True, hide_index=True)
else:
    st.caption("No sync attempts logged yet.")

with st.expander("Login attempt logs (US-01 unauthorized access tracking)"):
    with db.get_cursor() as cur:
        cur.execute("SELECT * FROM Login_Logs ORDER BY LogID DESC LIMIT 20")
        login_logs = [dict(r) for r in cur.fetchall()]
    if login_logs:
        rows = [{"When": l["AttemptedAt"], "Session": l["SessionID"], "User ID tried": l["UserIDTried"],
                  "Success": bool(l["Success"]), "Reason": l["Reason"]} for l in login_logs]
        st.dataframe(rows, use_container_width=True, hide_index=True)
    else:
        st.caption("No login attempts logged yet.")

if st.button("Simulate a failed sync (for demo)"):
    with db.get_cursor(commit=True) as cur:
        cur.execute(
            "INSERT INTO Sync_Logs (SessionID, Status, ErrorMessage, RetryCount, Timestamp) VALUES (?,?,?,?,?)",
            (st.session_state.get("session_id"), "FAILED", "Simulated: connection timeout to SQL Server host", 1, db.now_iso()),
        )
    st.rerun()
