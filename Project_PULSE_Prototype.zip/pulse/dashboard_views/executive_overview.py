import streamlit as st

import db
import program_ctx
import ui_helpers
import business_logic as bl

user = st.session_state["user"]
active_program = program_ctx.get_active_program()
ui_helpers.page_shell("Overview", user, active_program["ProgramName"], active_program["Term"])

program_id = active_program["ProgramID"]

# --- US-12: "data last updated" timestamp, visible on every major view ----
with db.get_cursor() as cur:
    cur.execute("SELECT LastSuccessfulSync FROM Sync_Status WHERE ProgramID=?", (program_id,))
    row = cur.fetchone()
last_sync = row["LastSuccessfulSync"] if row else "No sync recorded"
st.caption(f"🔄 Data last updated: **{last_sync}**")

# --- US-16: repeated failed syncs -> visible warning banner ----------------
with db.get_cursor() as cur:
    cur.execute("SELECT Status FROM Sync_Logs ORDER BY LogID DESC LIMIT 3")
    recent = [r["Status"] for r in cur.fetchall()]
if recent.count("FAILED") >= 2:
    st.error("⚠️ Multiple recent data-sync attempts have failed. See Admin Config → System Logs.")

# --- US-05: total enrolled headcount, clearly labeled with the term -------
with db.get_cursor() as cur:
    cur.execute("SELECT COUNT(*) c FROM Students WHERE ProgramID=?", (program_id,))
    total_enrolled = cur.fetchone()["c"]

    cur.execute(
        """SELECT sl.CourseworkStatus, sl.CompExamStatus, sl.CapstoneDefended, sl.CapstoneCompleted
           FROM Student_Lifecycle sl JOIN Students s ON s.StudentNumber = sl.StudentNumber
           WHERE s.ProgramID=?""",
        (program_id,),
    )
    lifecycle_rows = [dict(r) for r in cur.fetchall()]

at_risk_days = bl.get_at_risk_days(program_id)
completed = sum(1 for r in lifecycle_rows if r["CapstoneCompleted"])
in_coursework = sum(1 for r in lifecycle_rows if r["CourseworkStatus"] != "Completed")
in_comp_exam = sum(1 for r in lifecycle_rows if r["CourseworkStatus"] == "Completed" and r["CompExamStatus"] != "Passed")
in_capstone = sum(1 for r in lifecycle_rows if r["CompExamStatus"] == "Passed" and not r["CapstoneCompleted"])

k1, k2, k3, k4 = st.columns(4)
k1.metric(f"Total Enrolled — {active_program['Term']}", total_enrolled)
k2.metric("Completed Program", completed)
k3.metric("Remaining Students", total_enrolled - completed)
k4.metric("Overall Completion %", f"{(completed/total_enrolled*100 if total_enrolled else 0):.1f}%")

st.subheader("Cohort by Lifecycle Stage")
c1, c2, c3 = st.columns(3)
c1.metric("In Coursework", in_coursework)
c2.metric("In Comprehensive Exam", in_comp_exam)
c3.metric("In Capstone", in_capstone)

# --- Students at risk (uses US-14 RYG rule: red = at/over threshold) -------
st.subheader("Students At Risk — Requires Follow-Up")
st.caption(f"Auto-flagged when a student remains on a stage past its configured threshold ({at_risk_days} days).")

with db.get_cursor() as cur:
    cur.execute(
        """SELECT s.StudentNumber, s.FirstName, s.LastName, s.Cohort,
                  sl.CourseworkStatus, sl.CompExamStatus, sl.CapstoneDefended, sl.CapstoneCompleted,
                  sl.CourseworkUpdated, sl.CompExamUpdated, sl.CapstoneUpdated
           FROM Student_Lifecycle sl JOIN Students s ON s.StudentNumber = sl.StudentNumber
           WHERE s.ProgramID=?""",
        (program_id,),
    )
    students = [dict(r) for r in cur.fetchall()]

at_risk_rows = []
for s in students:
    capstone_status = bl.derive_capstone_status(s["CompExamStatus"], bool(s["CapstoneDefended"]), bool(s["CapstoneCompleted"]))
    # whichever stage is currently active determines the "time in stage"
    if s["CourseworkStatus"] != "Completed":
        stage, status, last_updated = "Coursework", s["CourseworkStatus"], s["CourseworkUpdated"]
    elif s["CompExamStatus"] != "Passed":
        stage, status, last_updated = "Comprehensive Exam", s["CompExamStatus"], s["CompExamUpdated"]
    else:
        stage, status, last_updated = "Capstone", capstone_status, s["CapstoneUpdated"]

    indicator = bl.stage_indicator(status, last_updated, at_risk_days)
    if indicator == bl.RYG["red"] and status not in ("Completed", "Passed", "Cancelled"):
        at_risk_rows.append({
            "Student": f"{s['FirstName']} {s['LastName']}",
            "ID": s["StudentNumber"],
            "Cohort": s["Cohort"],
            "Stage": stage,
            "Status": status,
            "Days in Stage": bl.days_since(last_updated),
            "Flag": f"{indicator['symbol']} {indicator['label']}",
        })

if at_risk_rows:
    st.dataframe(at_risk_rows, use_container_width=True, hide_index=True)
else:
    st.success("No students currently over the at-risk threshold.")
