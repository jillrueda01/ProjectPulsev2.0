import streamlit as st

import db
import program_ctx
import ui_helpers
import business_logic as bl

user = st.session_state["user"]
active_program = program_ctx.get_active_program()
ui_helpers.page_shell("Roster", user, active_program["ProgramName"], active_program["Term"])
program_id = active_program["ProgramID"]
at_risk_days = bl.get_at_risk_days(program_id)

with db.get_cursor() as cur:
    cur.execute("SELECT LastSuccessfulSync FROM Sync_Status WHERE ProgramID=?", (program_id,))
    row = cur.fetchone()
st.caption(f"Live view · data last synced {row['LastSuccessfulSync'] if row else 'never'}")

# --- Filters: US-06 (cohort), plus advisor/status filters shown in the mock,
# and US-15 search by name or ID. --------------------------------------------
with db.get_cursor() as cur:
    cur.execute("SELECT DISTINCT Cohort FROM Students WHERE ProgramID=? ORDER BY Cohort DESC", (program_id,))
    cohorts = [r["Cohort"] for r in cur.fetchall()]
    cur.execute(
        """SELECT DISTINCT a.AdvisorName FROM Advisor a
           JOIN Student_Advisor sa ON sa.AdvisorID = a.AdvisorID
           JOIN Students s ON s.StudentNumber = sa.StudentNumber
           WHERE s.ProgramID=? ORDER BY a.AdvisorName""",
        (program_id,),
    )
    advisors = [r["AdvisorName"] for r in cur.fetchall()]

f1, f2, f3, f4 = st.columns([1, 1, 1, 2])
cohort_filter = f1.selectbox("Cohort", ["All Cohorts"] + cohorts)
advisor_filter = f2.selectbox("Advisor", ["All Advisors"] + advisors)
status_filter = f3.selectbox("Status", ["All Statuses", "At Risk", "On Track"])
search_term = f4.text_input("Search name or student ID", placeholder="e.g. Santos or MBA-2401")

# --- Pull the roster ---------------------------------------------------------
with db.get_cursor() as cur:
    cur.execute(
        """SELECT s.StudentNumber, s.FirstName, s.LastName, s.Cohort, s.EnrollmentStatus,
                  GROUP_CONCAT(DISTINCT a.AdvisorName) AS Advisors,
                  sl.CourseworkStatus, sl.CompExamStatus, sl.CapstoneDefended, sl.CapstoneCompleted,
                  sl.CourseworkUpdated, sl.CompExamUpdated, sl.CapstoneUpdated
           FROM Students s
           LEFT JOIN Student_Advisor sa ON sa.StudentNumber = s.StudentNumber
           LEFT JOIN Advisor a ON a.AdvisorID = sa.AdvisorID
           LEFT JOIN Student_Lifecycle sl ON sl.StudentNumber = s.StudentNumber
           WHERE s.ProgramID = ?
           GROUP BY s.StudentNumber
           ORDER BY s.LastName, s.FirstName""",
        (program_id,),
    )
    rows = [dict(r) for r in cur.fetchall()]

table_rows = []
for r in rows:
    if cohort_filter != "All Cohorts" and r["Cohort"] != cohort_filter:
        continue
    if advisor_filter != "All Advisors" and (not r["Advisors"] or advisor_filter not in r["Advisors"]):
        continue
    if search_term:
        needle = search_term.strip().lower()
        haystack = f"{r['FirstName']} {r['LastName']} {r['StudentNumber']}".lower()
        if needle not in haystack:
            continue

    capstone_status = bl.derive_capstone_status(r["CompExamStatus"], bool(r["CapstoneDefended"]), bool(r["CapstoneCompleted"]))

    # Overall risk = worst indicator across the three active stages (US-14)
    stage_checks = [
        (r["CourseworkStatus"], r["CourseworkUpdated"]),
        (r["CompExamStatus"], r["CompExamUpdated"]) if r["CourseworkStatus"] == "Completed" else (None, None),
        (capstone_status, r["CapstoneUpdated"]) if r["CompExamStatus"] == "Passed" else (None, None),
    ]
    worst = bl.RYG["green"]
    for status, updated in stage_checks:
        if status is None:
            continue
        ind = bl.stage_indicator(status, updated, at_risk_days)
        if ind == bl.RYG["red"]:
            worst = bl.RYG["red"]
            break
        if ind == bl.RYG["amber"] and worst != bl.RYG["red"]:
            worst = bl.RYG["amber"]

    is_at_risk = worst == bl.RYG["red"]
    if status_filter == "At Risk" and not is_at_risk:
        continue
    if status_filter == "On Track" and is_at_risk:
        continue

    table_rows.append({
        "Student": f"{r['FirstName']} {r['LastName']}",
        "ID": r["StudentNumber"],
        "Cohort": r["Cohort"],
        "Advisor(s)": r["Advisors"] or "—",
        "Coursework": r["CourseworkStatus"],
        "Comp. Exam": r["CompExamStatus"],
        "Capstone": capstone_status,
        "Risk": f"{worst['symbol']} {worst['label']}",
    })

st.markdown(f"### {active_program['ProgramName']} Roster ({len(table_rows)} students)")

if not table_rows:
    # US-15 AC: no-results state must be clearly displayed
    st.info("No students match the current filters/search. Try clearing a filter.")
else:
    # US-04: clicking a row opens that student's profile.
    event = st.dataframe(
        table_rows,
        use_container_width=True,
        hide_index=True,
        on_select="rerun",
        selection_mode="single-row",
        key="roster_table",
    )
    if event and event.selection and event.selection.get("rows"):
        idx = event.selection["rows"][0]
        st.session_state["selected_student"] = table_rows[idx]["ID"]
        st.switch_page("dashboard_views/student_profile.py")

    st.caption("Tip: click any row to open that student's full profile. Click a column header to sort.")
