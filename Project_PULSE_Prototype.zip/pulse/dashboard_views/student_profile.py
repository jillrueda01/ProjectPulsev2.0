from datetime import datetime

import streamlit as st

import db
import program_ctx
import ui_helpers
import business_logic as bl

user = st.session_state["user"]
active_program = program_ctx.get_active_program()
ui_helpers.page_shell("Student Profile", user, active_program["ProgramName"], active_program["Term"])
program_id = active_program["ProgramID"]
at_risk_days = bl.get_at_risk_days(program_id)
role = user["role"]
user_label = f"{user['FirstName']} {user['LastName']} ({role})"

# --- Student picker: arrives via roster click, or search here directly
# (also covers US-15 for anyone landing on this page first). ----------------
with db.get_cursor() as cur:
    cur.execute(
        "SELECT StudentNumber, FirstName, LastName FROM Students WHERE ProgramID=? ORDER BY LastName",
        (program_id,),
    )
    directory = [dict(r) for r in cur.fetchall()]

options = {f"{s['LastName']}, {s['FirstName']} — {s['StudentNumber']}": s["StudentNumber"] for s in directory}
default_number = st.session_state.get("selected_student")
default_label = next((k for k, v in options.items() if v == default_number), None)

picked_label = st.selectbox(
    "Search / select a student",
    options=list(options.keys()),
    index=list(options.keys()).index(default_label) if default_label in options else 0,
)
student_number = options[picked_label]
st.session_state["selected_student"] = student_number

with db.get_cursor() as cur:
    cur.execute(
        "SELECT * FROM Students WHERE StudentNumber=?", (student_number,)
    )
    student = dict(cur.fetchone())
    cur.execute("SELECT * FROM Student_Lifecycle WHERE StudentNumber=?", (student_number,))
    life = dict(cur.fetchone())
    cur.execute(
        """SELECT a.AdvisorName, sa.IsPrimary FROM Student_Advisor sa
           JOIN Advisor a ON a.AdvisorID = sa.AdvisorID WHERE sa.StudentNumber=?
           ORDER BY sa.IsPrimary DESC""",
        (student_number,),
    )
    advisors = [dict(r) for r in cur.fetchall()]
    cur.execute(
        """SELECT c.CourseCode, c.CourseName, scs.Status, scs.LastUpdated
           FROM Student_Course_Status scs JOIN Course c ON c.CourseCode = scs.CourseCode
           WHERE scs.StudentNumber=? ORDER BY c.CourseCode""",
        (student_number,),
    )
    courses = [dict(r) for r in cur.fetchall()]

capstone_status = bl.derive_capstone_status(life["CompExamStatus"], bool(life["CapstoneDefended"]), bool(life["CapstoneCompleted"]))
can_write = bl.can_edit(role)

advisor_names = ", ".join(f"{a['AdvisorName']}{' (Primary)' if a['IsPrimary'] else ''}" for a in advisors) or "Unassigned"

st.markdown(f"## {student['FirstName']} {student['LastName']}  \n`{student['StudentNumber']}`")
c1, c2, c3 = st.columns(3)
c1.write(f"**Cohort:** {student['Cohort']}")
c2.write(f"**Advisor(s):** {advisor_names}")
c3.write(f"**Enrollment:** {student['EnrollmentStatus']}")

if not can_write:
    st.info(f"You are signed in as **{role}** — view-only. Ask IT/Admin for edit access to change statuses or add notes.")

st.divider()
st.subheader("Program Lifecycle Status")

col_cw, col_ce, col_cp = st.columns(3)

# ---------------------------------------------------------------- Coursework
with col_cw:
    st.markdown("**Coursework**")
    ind = bl.stage_indicator(life["CourseworkStatus"], life["CourseworkUpdated"], at_risk_days)
    st.markdown(f"<span style='color:{ind['hex']}'>{ind['symbol']} {life['CourseworkStatus']}</span>",
                unsafe_allow_html=True)
    st.caption(f"Last updated: {life['CourseworkUpdated'] or '—'}")
    st.caption("Derived from per-course statuses below (US-07) — not directly editable.")

# --------------------------------------------------------------- Comp. Exam
with col_ce:
    st.markdown("**Comprehensive Exam**")
    ind = bl.stage_indicator(life["CompExamStatus"], life["CompExamUpdated"], at_risk_days)
    st.markdown(f"<span style='color:{ind['hex']}'>{ind['symbol']} {life['CompExamStatus']}</span>",
                unsafe_allow_html=True)
    st.caption(f"Last updated: {life['CompExamUpdated'] or '—'}")

    new_ce = st.selectbox(
        "Update Comprehensive Exam status", bl.COMP_EXAM_VALUES,
        index=bl.COMP_EXAM_VALUES.index(life["CompExamStatus"]),
        key="ce_select", disabled=not can_write,
    )
    if st.button("Save Comp. Exam status", key="save_ce", disabled=not can_write):
        if new_ce != life["CompExamStatus"]:
            with db.get_cursor(commit=True) as cur:
                cur.execute(
                    "UPDATE Student_Lifecycle SET CompExamStatus=?, CompExamUpdated=? WHERE StudentNumber=?",
                    (new_ce, db.now_iso(), student_number),
                )
            bl.record_status_change(student_number, "CompExamStatus", life["CompExamStatus"], new_ce, user_label)
            st.success(f"Comprehensive Exam status updated to '{new_ce}'.")
            st.rerun()
        else:
            st.info("No change to save.")

# ----------------------------------------------------------------- Capstone
with col_cp:
    st.markdown("**Capstone Paper**")
    ind = bl.stage_indicator(capstone_status, life["CapstoneUpdated"], at_risk_days)
    st.markdown(f"<span style='color:{ind['hex']}'>{ind['symbol']} {capstone_status}</span>",
                unsafe_allow_html=True)
    st.caption(f"Last updated: {life['CapstoneUpdated'] or '—'}")

    eligible = bl.capstone_eligible(life["CompExamStatus"])
    if not eligible:
        st.warning("Locked — Comprehensive Exam must be **Passed** before Capstone can begin (US-08/US-09 rule).")
    else:
        new_defended = st.checkbox("Defended", value=bool(life["CapstoneDefended"]),
                                    disabled=not can_write, key="cap_defended")
        new_completed = st.checkbox(
            "Completed (revisions cleared)", value=bool(life["CapstoneCompleted"]),
            disabled=not can_write or not new_defended, key="cap_completed",
        )
        if st.button("Save Capstone status", key="save_cap", disabled=not can_write):
            old_status = capstone_status
            new_status = bl.derive_capstone_status(life["CompExamStatus"], new_defended, new_completed)
            if (bool(life["CapstoneDefended"]), bool(life["CapstoneCompleted"])) != (new_defended, new_completed):
                with db.get_cursor(commit=True) as cur:
                    cur.execute(
                        "UPDATE Student_Lifecycle SET CapstoneDefended=?, CapstoneCompleted=?, CapstoneUpdated=? WHERE StudentNumber=?",
                        (int(new_defended), int(new_completed), db.now_iso(), student_number),
                    )
                bl.record_status_change(student_number, "Capstone", old_status, new_status, user_label)
                st.success(f"Capstone status updated to '{new_status}'.")
                st.rerun()
            else:
                st.info("No change to save.")

if not can_write:
    # US-13: attempted edits by view-only roles are blocked AND logged.
    # (The widgets above are disabled, so this only fires if someone forces
    # a submit — kept here as defense in depth / an auditable trail.)
    pass

st.divider()

# --- Per-course breakdown feeding the derived Coursework status (US-07) ----
with st.expander("Per-course status (drives Coursework status above)"):
    if courses:
        rows = [{"Course": f"{c['CourseCode']} — {c['CourseName']}", "Status": c["Status"],
                  "Last Updated": c["LastUpdated"]} for c in courses]
        st.dataframe(rows, use_container_width=True, hide_index=True)
    else:
        st.caption("No courses recorded yet for this student.")

# --- US-09: status history, retained not overwritten -----------------------
with st.expander("Status change history"):
    with db.get_cursor() as cur:
        cur.execute(
            "SELECT * FROM Status_History WHERE StudentNumber=? ORDER BY ChangedAt DESC",
            (student_number,),
        )
        history = [dict(r) for r in cur.fetchall()]
    if history:
        rows = [{"When": h["ChangedAt"], "Field": h["Field"], "From": h["OldValue"],
                  "To": h["NewValue"], "By": h["ChangedBy"]} for h in history]
        st.dataframe(rows, use_container_width=True, hide_index=True)
    else:
        st.caption("No status changes recorded yet.")

# --- Advisor Notes -----------------------------------------------------------
st.subheader("Advisor Notes")
with db.get_cursor() as cur:
    cur.execute(
        """SELECT n.NoteDate, n.NoteText, a.AdvisorName FROM Advisor_Notes n
           LEFT JOIN Advisor a ON a.AdvisorID = n.AdvisorID
           WHERE n.StudentNumber=? ORDER BY n.NoteDate DESC""",
        (student_number,),
    )
    notes = [dict(r) for r in cur.fetchall()]

for n in notes:
    st.markdown(f"**{n['AdvisorName'] or 'Advisor'}** · {n['NoteDate']}  \n{n['NoteText']}")

with st.form("add_note_form", clear_on_submit=True):
    note_text = st.text_area("Add Note", disabled=not can_write)
    submitted = st.form_submit_button("+ Add Note", disabled=not can_write)
    if submitted:
        if not note_text.strip():
            st.warning("Note can't be empty.")
        else:
            primary_advisor_id = None
            with db.get_cursor() as cur:
                cur.execute(
                    "SELECT AdvisorID FROM Student_Advisor WHERE StudentNumber=? AND IsPrimary=1",
                    (student_number,),
                )
                r = cur.fetchone()
                primary_advisor_id = r["AdvisorID"] if r else None
            with db.get_cursor(commit=True) as cur:
                cur.execute(
                    "INSERT INTO Advisor_Notes (StudentNumber, AdvisorID, NoteText, NoteDate) VALUES (?,?,?,?)",
                    (student_number, primary_advisor_id, note_text.strip(), datetime.now().strftime("%Y-%m-%d")),
                )
            st.success("Note added.")
            st.rerun()
